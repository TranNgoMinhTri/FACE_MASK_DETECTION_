# Face mask > 2022-09-20 12:06am
https://universe.roboflow.com/object-detection/face-mask-wokhz

Provided by Roboflow
License: CC BY 4.0

